
<p align="center">
<a href="https://github.com/mrfzvx12"><img title="mrfzvx12" src="https://img.shields.io/badge/github-Mrfzvx12-orange.svg?style=social&logo=github"></a>
</p>
<p align="center">
<img src="https://gpvc.arturio.dev/mrfzvx12" />
<a href="https://github.com/mrfzvx12"><img title="Author" src="https://img.shields.io/badge/Termux Whatsapp Bot-V2-orange?style=for-the-badge&logo=github"></a>
<a href="https://github.com/mrfzvx12/followers"><img title="Followers" src="https://img.shields.io/github/followers/mrfzvx12?label=Followers&style=social"></a>
<a href="https://github.com/mrfzvx12/im-lexa-v2/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/mrfzvx12/termux-whatsapp-bot?&style=social"></a>
<a href="https://github.com/mrfzvx12/im-lexa-v2/network/members"><img title="Fork" src="https://img.shields.io/github/forks/mrfzvx12/termux-whatsapp-bot?style=social"></a>
<a href="https://github.com/mrfzvx12/im-lexa-v2/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/mrfzvx12/termux-whatsapp-bot?label=Watching&style=social"></a>
<a href="https://github.com/mrfzvx12/im-lexa-v2/watchers"><img title="Contributor" src="https://img.shields.io/github/contributors/mrfzvx12/termux-whatsapp-bot?logo=github&style=social"></a>
</p>
<p align="center">
<a href="https://github.com/mrfzvx12/im-lexa-v2"><img src="https://img.shields.io/github/repo-size/mrfzvx12/im-lexa-v2?label=Repo%20size&style=plastic"></a>
<a href="https://github.com/mrfzvx12/im-lexa-v2"><img src="https://img.shields.io/github/search/mrfzvx12/mrfzvx12/whatsapp?label=Search&style=plastic"></a>
</p>

### New version
<p>
<a href="https://github.com/mrfzvx12/lexav3" target="blank"><img src="https://img.shields.io/badge/Versi Terbaru Lexa V3-30302f?style=flat&logo=github" /></a>
</p>
